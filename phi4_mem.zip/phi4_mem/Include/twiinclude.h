#ifndef __TWIINCLUDE 
#define __TWIINCLUDE

#include "twiprobe.h"
#include "twivar.h"

#endif 
